package com.createdby.rostrick;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * RosTrick: العمل في الخلفية (اختياري).
 * - أ) خدمة أمامية RtBackgroundService (إشعار دائم) — تُضاف للـ Manifest فقط إذا اختار صاحب التطبيق "bg_service".
 * - ب) مهام مجدولة عبر AlarmManager + RtAlarmReceiver — تُضاف فقط إذا اختار "bg_scheduler".
 * الكلاسات موجودة دائماً في القالب، لكنها لا تعمل إلا إذا كانت معلنة في AndroidManifest.xml (apply_config.py).
 */
public final class RtBackground {
	private RtBackground() {}

	static final String PREFS = "rt_background";
	static final String K_ALARMS = "alarms";
	static final String K_SVC = "svc";            // JSON إعدادات الخدمة إن كانت مطلوبة التشغيل
	static final String CH_SERVICE = "rt_bg_service";
	static final String CH_ALARM = "rt_bg_alarm";
	static final String ACTION_ALARM = "com.createdby.rostrick.RT_ALARM";
	static final long MIN_REPEAT_MS = 60000L;

	static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

	// ---------- هل المكوّن معلن في الـ Manifest؟ ----------
	static boolean serviceDeclared(Context c) {
		try { c.getPackageManager().getServiceInfo(new ComponentName(c, RtBackgroundService.class), 0); return true; }
		catch (Throwable t) { return false; }
	}
	static boolean schedulerDeclared(Context c) {
		try { c.getPackageManager().getReceiverInfo(new ComponentName(c, RtAlarmReceiver.class), 0); return true; }
		catch (Throwable t) { return false; }
	}

	// ---------- القنوات والإشعارات ----------
	static void ensureChannel(Context c, String id, String name, int importance) {
		if (Build.VERSION.SDK_INT < 26) return;
		try {
			NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
			if (nm != null && nm.getNotificationChannel(id) == null) nm.createNotificationChannel(new NotificationChannel(id, name, importance));
		} catch (Throwable ignored) {}
	}

	static PendingIntent openAppIntent(Context c, int reqCode, String page) {
		Intent i = new Intent(c, MainActivity.class);
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
		if (page != null && page.length() > 0) i.putExtra("rt_page", page);
		int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
		return PendingIntent.getActivity(c, reqCode, i, fl);
	}

	static void showNotification(Context c, String id, String title, String text, String page) {
		try {
			ensureChannel(c, CH_ALARM, RtI18n.t("تنبيهات التطبيق", "App alerts"), NotificationManager.IMPORTANCE_HIGH);
			Notification.Builder b = (Build.VERSION.SDK_INT >= 26) ? new Notification.Builder(c, CH_ALARM) : new Notification.Builder(c);
			int icon = c.getApplicationInfo().icon;
			b.setSmallIcon(icon != 0 ? icon : android.R.drawable.ic_popup_reminder);
			b.setContentTitle(title != null && title.length() > 0 ? title : c.getApplicationInfo().loadLabel(c.getPackageManager()).toString());
			if (text != null && text.length() > 0) { b.setContentText(text); b.setStyle(new Notification.BigTextStyle().bigText(text)); }
			b.setAutoCancel(true);
			if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH);
			b.setContentIntent(openAppIntent(c, Math.abs(id.hashCode()), page));
			NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
			if (nm != null) nm.notify(("rtalarm:" + id), 0, b.build());
		} catch (Throwable t) { t.printStackTrace(); }
	}

	// ---------- تخزين المنبّهات ----------
	static synchronized JSONObject loadAlarms(Context c) {
		try { return new JSONObject(prefs(c).getString(K_ALARMS, "{}")); } catch (Throwable t) { return new JSONObject(); }
	}
	static synchronized void saveAlarms(Context c, JSONObject o) {
		prefs(c).edit().putString(K_ALARMS, o.toString()).apply();
	}

	static PendingIntent alarmPending(Context c, String id) {
		Intent i = new Intent(c, RtAlarmReceiver.class);
		i.setAction(ACTION_ALARM);
		i.setData(Uri.parse("rtalarm://" + Uri.encode(id)));
		i.putExtra("id", id);
		int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
		return PendingIntent.getBroadcast(c, Math.abs(id.hashCode()), i, fl);
	}

	static boolean canExact(Context c) {
		if (Build.VERSION.SDK_INT < 31) return true;
		try { AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE); return am != null && am.canScheduleExactAlarms(); }
		catch (Throwable t) { return false; }
	}

	/** يضبط المنبّه في النظام (دون تغيير التخزين). */
	static void arm(Context c, JSONObject a) {
		try {
			AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
			if (am == null) return;
			String id = a.getString("id");
			long at = a.getLong("at");
			PendingIntent pi = alarmPending(c, id);
			boolean exact = a.optBoolean("exact", true) && canExact(c);
			try {
				if (Build.VERSION.SDK_INT >= 23) {
					if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
					else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
				} else {
					if (exact) am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
					else am.set(AlarmManager.RTC_WAKEUP, at, pi);
				}
			} catch (SecurityException se) {
				// لم يُمنح إذن المنبّهات الدقيقة: نرجع للمنبّه غير الدقيق
				if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
				else am.set(AlarmManager.RTC_WAKEUP, at, pi);
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	static long repeatMs(Object r) {
		if (r == null) return 0;
		String s = String.valueOf(r).trim().toLowerCase();
		if (s.length() == 0 || "none".equals(s) || "null".equals(s) || "false".equals(s) || "0".equals(s)) return 0;
		if ("daily".equals(s)) return 86400000L;
		if ("hourly".equals(s)) return 3600000L;
		if ("weekly".equals(s)) return 7 * 86400000L;
		try { long v = (long) Double.parseDouble(s); return v < MIN_REPEAT_MS ? MIN_REPEAT_MS : v; } catch (Throwable t) { return 0; }
	}

	/** يسجّل منبّهاً جديداً. at = وقت بالمللي ثانية (epoch) أو in = بعد كم ثانية. */
	static boolean schedule(Context c, JSONObject in) {
		try {
			String id = in.optString("id", "").trim();
			if (id.length() == 0 || id.length() > 64) return false;
			long now = System.currentTimeMillis();
			long at;
			if (in.has("in")) at = now + (long) (in.getDouble("in") * 1000);
			else at = in.getLong("at");
			long rep = repeatMs(in.opt("repeat"));
			if (at <= now) {
				if (rep <= 0) return false;
				at += ((now - at) / rep + 1) * rep;   // أقرب موعد قادم لمنبّه متكرر
			}
			JSONObject a = new JSONObject();
			a.put("id", id);
			a.put("at", at);
			a.put("repeat", rep);
			a.put("title", clip(in.optString("title", ""), 120));
			a.put("text", clip(in.optString("text", ""), 400));
			a.put("page", safePage(in.optString("page", "")));
			a.put("exact", in.optBoolean("exact", true));
			synchronized (RtBackground.class) {
				JSONObject all = loadAlarms(c);
				if (!all.has(id) && all.length() >= 200) return false;
				all.put(id, a);
				saveAlarms(c, all);
			}
			arm(c, a);
			return true;
		} catch (Throwable t) { t.printStackTrace(); return false; }
	}

	static void cancel(Context c, String id) {
		try {
			AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
			if (am != null) am.cancel(alarmPending(c, id));
			synchronized (RtBackground.class) {
				JSONObject all = loadAlarms(c);
				if (all.has(id)) { all.remove(id); saveAlarms(c, all); }
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	static void cancelAll(Context c) {
		try {
			JSONObject all = loadAlarms(c);
			Iterator<String> it = all.keys();
			while (it.hasNext()) {
				String id = it.next();
				AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
				if (am != null) am.cancel(alarmPending(c, id));
			}
			saveAlarms(c, new JSONObject());
		} catch (Throwable t) { t.printStackTrace(); }
	}

	static JSONArray list(Context c) {
		JSONArray arr = new JSONArray();
		try {
			JSONObject all = loadAlarms(c);
			Iterator<String> it = all.keys();
			while (it.hasNext()) arr.put(all.getJSONObject(it.next()));
		} catch (Throwable ignored) {}
		return arr;
	}

	/** بعد إعادة التشغيل أو تحديث التطبيق: يعيد ضبط كل المنبّهات المحفوظة. */
	static void rescheduleAll(Context c) {
		try {
			synchronized (RtBackground.class) {
				JSONObject all = loadAlarms(c);
				long now = System.currentTimeMillis();
				boolean changed = false;
				Iterator<String> it = all.keys();
				java.util.ArrayList<String> drop = new java.util.ArrayList<String>();
				while (it.hasNext()) {
					String id = it.next();
					JSONObject a = all.getJSONObject(id);
					long at = a.optLong("at", 0), rep = a.optLong("repeat", 0);
					if (at <= now) {
						if (rep > 0) { at += ((now - at) / rep + 1) * rep; a.put("at", at); changed = true; }
						else { drop.add(id); changed = true; continue; }
					}
					arm(c, a);
				}
				for (String id : drop) all.remove(id);
				if (changed) saveAlarms(c, all);
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	static String clip(String s, int n) { return s == null ? "" : (s.length() > n ? s.substring(0, n) : s); }

	/** اسم صفحة محلية فقط (بلا مسارات) — نفس قيد rt_page في MainActivity. */
	static String safePage(String p) {
		if (p == null) return "";
		p = p.trim();
		if (p.length() == 0 || p.length() >= 160 || p.indexOf('/') >= 0 || p.indexOf('\\') >= 0 || p.contains("..")) return "";
		return p;
	}
}
