package com.createdby.rostrick;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/** RosTrick: يستقبل المنبّهات المجدولة (RosTrickBackground.schedule) ويعرض إشعارها، ثم يعيد جدولة المتكرر. */
public class RtAlarmReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context ctx, Intent intent) {
		try {
			if (intent == null || !RtBackground.ACTION_ALARM.equals(intent.getAction())) return;
			String id = intent.getStringExtra("id");
			if (id == null) return;
			JSONObject a;
			synchronized (RtBackground.class) {
				JSONObject all = RtBackground.loadAlarms(ctx);
				a = all.optJSONObject(id);
				if (a == null) return;   // أُلغي قبل موعده
				long rep = a.optLong("repeat", 0);
				if (rep > 0) {
					long now = System.currentTimeMillis();
					long at = a.optLong("at", now);
					at += ((Math.max(now, at) - at) / rep + 1) * rep;
					a.put("at", at);
					all.put(id, a);
					RtBackground.saveAlarms(ctx, all);
					RtBackground.arm(ctx, a);
				} else {
					all.remove(id);
					RtBackground.saveAlarms(ctx, all);
				}
			}
			RtBackground.showNotification(ctx, id, a.optString("title", ""), a.optString("text", ""), a.optString("page", ""));
		} catch (Throwable t) { t.printStackTrace(); }
	}
}
