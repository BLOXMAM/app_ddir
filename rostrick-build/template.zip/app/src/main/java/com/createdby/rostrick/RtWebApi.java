package com.createdby.rostrick;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.ContactsContract;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * RosTrick: واجهات المتصفح القياسية التي لا يوفّرها WebView لصفحات file:// — clipboard, wakeLock, Notification,
 * getBattery, contacts. الصفحة تستعملها بأسمائها القياسية (navigator.clipboard ...) والتحويل إلى هنا يتم في
 * assets/rt-webapi.js. تعمل دائماً بلا إعداد، ولا تحتاج مكتبات إضافية.
 * كل ردّ غير متزامن يعود للصفحة عبر window.__rtWA(id, json)، والأحداث عبر window.__rtWAEv(name, json).
 */
public final class RtWebApi {
	private static final int REQ_CONTACT = 7311;
	private static final int REQ_NOTIF = 7310;
	private static final String CHANNEL_ID = "rt_web_notifications";
	private static final String PREFS = "rostrick_webapi";

	private final Activity act;
	private final WebView web;
	private int pendingContactId = 0;
	private String pendingContactProps = "";
	private int pendingNotifId = 0;
	private BroadcastReceiver batteryReceiver = null;

	public RtWebApi(Activity activity, WebView webView) {
		this.act = activity;
		this.web = webView;
	}

	// ---------- مساعدات ----------
	private void reply(final int id, final String json) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtWA&&window.__rtWA(" + id + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private void event(final String name, final String json) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtWAEv&&window.__rtWAEv(" + JSONObject.quote(name) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private static String err(String message) {
		try { return new JSONObject().put("ok", false).put("error", message).toString(); } catch (Throwable t) { return "{\"ok\":false}"; }
	}

	// ---------- الحافظة: navigator.clipboard ----------
	@JavascriptInterface
	public void clipboardWrite(final int id, final String text) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
					if (cm == null) { reply(id, err("no clipboard")); return; }
					cm.setPrimaryClip(ClipData.newPlainText("text", text == null ? "" : text));
					reply(id, "{\"ok\":true}");
				} catch (Throwable t) { reply(id, err(String.valueOf(t))); }
			}
		});
	}

	@JavascriptInterface
	public void clipboardRead(final int id) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
					String text = "";
					if (cm != null && cm.hasPrimaryClip()) {
						ClipData cd = cm.getPrimaryClip();
						if (cd != null && cd.getItemCount() > 0) {
							CharSequence cs = cd.getItemAt(0).coerceToText(act);
							if (cs != null) text = cs.toString();
						}
					}
					reply(id, new JSONObject().put("ok", true).put("text", text).toString());
				} catch (Throwable t) { reply(id, err(String.valueOf(t))); }
			}
		});
	}

	// ---------- إبقاء الشاشة مضاءة: navigator.wakeLock ----------
	@JavascriptInterface
	public void wakeLockSet(final boolean on) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
					else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
				} catch (Throwable ignore) {}
			}
		});
	}

	// ---------- الإشعارات: window.Notification ----------
	private boolean notifEnabled() {
		try {
			NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
			if (nm == null) return false;
			if (Build.VERSION.SDK_INT >= 24) return nm.areNotificationsEnabled();
			return true;
		} catch (Throwable t) { return false; }
	}

	/** granted | denied | default */
	@JavascriptInterface
	public String notifPermission() {
		if (notifEnabled()) return "granted";
		SharedPreferences sp = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
		return sp.getBoolean("notif_asked", false) ? "denied" : "default";
	}

	@JavascriptInterface
	public void notifRequest(final int id) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					if (notifEnabled()) { reply(id, "{\"ok\":true,\"permission\":\"granted\"}"); return; }
					act.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("notif_asked", true).apply();
					if (Build.VERSION.SDK_INT >= 33) {
						pendingNotifId = id;
						act.requestPermissions(new String[]{ "android.permission.POST_NOTIFICATIONS" }, REQ_NOTIF);
					} else {
						reply(id, "{\"ok\":true,\"permission\":\"denied\"}");
					}
				} catch (Throwable t) { reply(id, "{\"ok\":true,\"permission\":\"denied\"}"); }
			}
		});
	}

	@JavascriptInterface
	public boolean notifShow(String tag, String title, String body) {
		try {
			if (!notifEnabled()) return false;
			NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
			if (nm == null) return false;
			Notification.Builder b;
			if (Build.VERSION.SDK_INT >= 26) {
				if (nm.getNotificationChannel(CHANNEL_ID) == null) {
					nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, RtI18n.t("إشعارات التطبيق", "App notifications"), NotificationManager.IMPORTANCE_DEFAULT));
				}
				b = new Notification.Builder(act, CHANNEL_ID);
			} else {
				b = new Notification.Builder(act);
			}
			String t = tag == null ? "" : tag;
			Intent open = new Intent(act, MainActivity.class);
			open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			open.putExtra("rt_notif_tag", t);
			int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
			PendingIntent pi = PendingIntent.getActivity(act, Math.abs(t.hashCode() % 100000), open, flags);
			b.setSmallIcon(act.getApplicationInfo().icon)
				.setContentTitle(title == null ? "" : title)
				.setContentText(body == null ? "" : body)
				.setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
				.setAutoCancel(true)
				.setContentIntent(pi);
			nm.notify(t, 7310, b.build());
			return true;
		} catch (Throwable e) { return false; }
	}

	@JavascriptInterface
	public void notifClose(String tag) {
		try {
			NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
			if (nm != null) nm.cancel(tag == null ? "" : tag, 7310);
		} catch (Throwable ignore) {}
	}

	// ---------- البطارية: navigator.getBattery() ----------
	private String batteryJson(Intent i) {
		try {
			if (i == null) i = act.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
			if (i == null) return "{\"ok\":false}";
			int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
			int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
			int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
			boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
			double lv = (level < 0 || scale <= 0) ? 1.0 : ((double) level / (double) scale);
			double chargingTime = -1;
			if (charging && Build.VERSION.SDK_INT >= 28) {
				BatteryManager bm = (BatteryManager) act.getSystemService(Context.BATTERY_SERVICE);
				if (bm != null) {
					long ms = bm.computeChargeTimeRemaining();
					if (ms > 0) chargingTime = ms / 1000.0;
				}
			}
			if (charging && status == BatteryManager.BATTERY_STATUS_FULL) chargingTime = 0;
			return new JSONObject().put("ok", true).put("level", lv).put("charging", charging).put("chargingTime", chargingTime).toString();
		} catch (Throwable t) { return "{\"ok\":false}"; }
	}

	/** حالة البطارية الحالية، ويبدأ مراقبتها لإرسال الأحداث للصفحة. */
	@JavascriptInterface
	public String batteryStart() {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					if (batteryReceiver != null) return;
					batteryReceiver = new BroadcastReceiver() {
						@Override public void onReceive(Context c, Intent i) { event("battery", batteryJson(i)); }
					};
					IntentFilter bf = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
					if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(batteryReceiver, bf, Context.RECEIVER_NOT_EXPORTED);
					else act.registerReceiver(batteryReceiver, bf);
				} catch (Throwable ignore) { batteryReceiver = null; }
			}
		});
		return batteryJson(null);
	}

	// ---------- جهات الاتصال: navigator.contacts.select() ----------
	@JavascriptInterface
	public void contactsSelect(final int id, final String propsCsv) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					if (pendingContactId != 0) { reply(id, err("busy")); return; }
					pendingContactId = id;
					pendingContactProps = propsCsv == null ? "" : propsCsv;
					Intent pick = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
					act.startActivityForResult(pick, REQ_CONTACT);
				} catch (Throwable t) { pendingContactId = 0; reply(id, err(String.valueOf(t))); }
			}
		});
	}

	private static void addUnique(JSONArray arr, String v) throws Exception {
		if (v == null) return;
		String s = v.trim();
		if (s.length() == 0) return;
		for (int i = 0; i < arr.length(); i++) if (s.equals(arr.optString(i))) return;
		arr.put(s);
	}

	private String readContact(Uri contactUri, String props) throws Exception {
		JSONArray names = new JSONArray(), tels = new JSONArray(), mails = new JSONArray();
		boolean gotData = false;
		try {
			Uri dataUri = Uri.withAppendedPath(contactUri, ContactsContract.Contacts.Data.CONTENT_DIRECTORY);
			Cursor c = act.getContentResolver().query(dataUri, new String[]{ ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1 }, null, null, null);
			if (c != null) {
				try {
					while (c.moveToNext()) {
						String mime = c.getString(0);
						String v = c.getString(1);
						if (ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE.equals(mime)) addUnique(names, v);
						else if (ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE.equals(mime)) addUnique(tels, v);
						else if (ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE.equals(mime)) addUnique(mails, v);
						gotData = true;
					}
				} finally { c.close(); }
			}
		} catch (Throwable ignore) {}
		if (names.length() == 0) {
			try {
				Cursor c = act.getContentResolver().query(contactUri, new String[]{ ContactsContract.Contacts.DISPLAY_NAME }, null, null, null);
				if (c != null) {
					try { if (c.moveToFirst()) addUnique(names, c.getString(0)); } finally { c.close(); }
				}
			} catch (Throwable ignore) {}
		}
		JSONObject o = new JSONObject();
		if (props.contains("name")) o.put("name", names);
		if (props.contains("tel")) o.put("tel", tels);
		if (props.contains("email")) o.put("email", mails);
		return o.toString();
	}

	// ---------- نتائج الأنشطة والأذونات (تُستدعى من MainActivity) ----------
	public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode != REQ_CONTACT) return false;
		final int id = pendingContactId;
		final String props = pendingContactProps;
		pendingContactId = 0;
		pendingContactProps = "";
		if (id == 0) return true;
		try {
			if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
				reply(id, "{\"ok\":true,\"contacts\":[]}");
				return true;
			}
			String one = readContact(data.getData(), props);
			reply(id, "{\"ok\":true,\"contacts\":[" + one + "]}");
		} catch (Throwable t) { reply(id, err(String.valueOf(t))); }
		return true;
	}

	public boolean onPermissionResult(int requestCode, int[] grantResults) {
		if (requestCode != REQ_NOTIF) return false;
		int id = pendingNotifId;
		pendingNotifId = 0;
		if (id != 0) {
			boolean ok = grantResults != null && grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
			reply(id, "{\"ok\":true,\"permission\":\"" + (ok ? "granted" : "denied") + "\"}");
		}
		return true;
	}

	/** يُستدعى عند وصول Intent جديد للتطبيق وهو يعمل (مثلاً الضغط على إشعار أنشأته الصفحة). */
	public void onNewIntent(Intent intent) {
		try {
			if (intent == null) return;
			String tag = intent.getStringExtra("rt_notif_tag");
			if (tag != null) {
				intent.removeExtra("rt_notif_tag");
				event("notifclick", new JSONObject().put("tag", tag).toString());
			}
		} catch (Throwable ignore) {}
	}

	public void onDestroy() {
		try { if (batteryReceiver != null) act.unregisterReceiver(batteryReceiver); } catch (Throwable ignore) {}
		batteryReceiver = null;
	}
}
