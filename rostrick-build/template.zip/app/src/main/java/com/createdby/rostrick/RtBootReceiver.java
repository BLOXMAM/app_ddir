package com.createdby.rostrick;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** RosTrick: بعد إعادة تشغيل الجهاز أو تحديث التطبيق — يعيد ضبط المنبّهات المجدولة ويُعيد الخدمة الأمامية إن كانت مفعّلة. */
public class RtBootReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context ctx, Intent intent) {
		try {
			String act = intent == null ? null : intent.getAction();
			if (act == null) return;
			if (!Intent.ACTION_BOOT_COMPLETED.equals(act) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(act)
				&& !"android.intent.action.QUICKBOOT_POWERON".equals(act)) return;
			if (RtBackground.schedulerDeclared(ctx)) RtBackground.rescheduleAll(ctx);
			if (RtBackground.serviceDeclared(ctx) && RtBackground.prefs(ctx).getString(RtBackground.K_SVC, null) != null) {
				Intent s = new Intent(ctx, RtBackgroundService.class);
				if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s); else ctx.startService(s);
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}
}
